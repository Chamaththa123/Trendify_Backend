﻿namespace WebService.Dto
{
    public class RankingDTO
    {
        public string CustomerId { get; set; }
        public string VendorId { get; set; }
        public int Ranking { get; set; }
    }
}
