﻿using WebService.Models;

namespace WebService.Dto
{
    public class VendorRegistrationDto
    {
        public User User { get; set; }
        public Vendor Vendor { get; set; }
    }
}
