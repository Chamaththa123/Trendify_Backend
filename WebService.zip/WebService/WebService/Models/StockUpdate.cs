﻿namespace WebService.Models
{
    public class StockUpdate
    {
        public int Type { get; set; } 
        public int StockChange { get; set; } 
    }
}
